export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        coffee: "#6F4E37",
        cream: "#F5E6D3"
      }
    }
  },
  plugins: []
}
